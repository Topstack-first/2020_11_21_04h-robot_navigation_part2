/**
 * Class PathNavigator implements algorithms for finding a path using
 a Stack or a Queue
 */
public class PathNavigator {

    private static final Move[] DIRS_TO_EXPLORE = new Move[]{
        Move.LEFT,
        Move.UP,
        Move.DOWN,
        Move.RIGHT
    };

    public DLLPath pathNavigatorUsingStack(Chessboard chessboard) {
        /*  TO DO Task #2: Stack Path Finder
         * 
         * - Create an empty Stack to store chessboard positions for future visits.
         * You can use the LinkedStack class already implemented on ADT.
         * - Start at position (0, 0)
         * - Navigate the given chessboard using depth-first search and stack till reach the goal
         * - Return DLLPath
         */
        
        final ChessboardPosition initPos = new ChessboardPosition(0, 0, null);
        LinkedStack<ChessboardPosition> posToExplore = new LinkedStack<ChessboardPosition>();
        
        DLLPath dllp = new DLLPath();
        
        posToExplore.push(initPos);
        
        ChessboardPosition explorePos = initPos;
        
        do
        {
            int stackSize = posToExplore.size();
            if(stackSize == 0)
            {
                break;//loop ended
            }
            
            explorePos = posToExplore.pop();
            
            ChessboardPosition prevPos = explorePos;
            
            chessboard.setPosStatus(explorePos, ChessboardStatus.VISITED);
            
            Move moveOperation;
            int i = 0;
            while(true) // for all directions
            {
                if(i == DIRS_TO_EXPLORE.length)
                {
                    break;
                }
                 moveOperation = DIRS_TO_EXPLORE[i];
                 i++;
                ChessboardPosition neighbourPos = chessboard.getNeighbour(explorePos, moveOperation);
                if(neighbourPos == null)
                {
                    continue;
                }
                ChessboardStatus neighbourStatus = chessboard.getPosStatus(neighbourPos);
                
                if(neighbourStatus == ChessboardStatus.GOAL)
                {
                    explorePos = neighbourPos;
                    explorePos.from = prevPos;

                    // goal is finded!
                    ChessboardPosition tmpPos;
                    for(tmpPos = explorePos; tmpPos != null ;tmpPos = tmpPos.from)
                    {
                        int[] coords = tmpPos.getCoords();
                        dllp.addFirst(coords[0], coords[1]);
                    }
                    return dllp;
                }
                if(neighbourStatus == ChessboardStatus.OPEN)
                {
                    ChessboardPosition tmpPos = neighbourPos;
                    tmpPos.from = prevPos;
                    posToExplore.push(tmpPos);
                }
            }
        }
        while( true );
        
        return null;
       // DLLPath dllp=buildPath(chessboard,mov);
       // return dllp;
    }

    public DLLPath pathNavigatorUsingQueue(Chessboard chessboard) {
         /*  Task #3: Queue Path Finder
         * 
         * - Create an empty Stack to store chessboard positions for future visits.
         * You can use the LinkedStack class already implemented on ADT.
         * - Start at position (0, 0)
         * - Navigate the given chessboard using breadth-first search and stack till reach the goal
         * - Return DLLPath
         */

        final ChessboardPosition initPos = new ChessboardPosition(0, 0, null);

        LinkedQueue<ChessboardPosition> posToExplore = new LinkedQueue<ChessboardPosition>();
        
        DLLPath dllp = new DLLPath();
        posToExplore.enqueue(initPos);
        ChessboardPosition explorePos = initPos;
        
        do
        {
            int stackSize = posToExplore.length();
            if(stackSize == 0)
            {
                break;//loop ended
            }
            explorePos = posToExplore.dequeue();
            ChessboardPosition prevPos = explorePos;
            Move moveOperation;
            int i = 0;
            while(true) // for all directions
            {
                if(i == DIRS_TO_EXPLORE.length)
                {
                    break;
                }
                 moveOperation = DIRS_TO_EXPLORE[i];
                 i++;
                ChessboardPosition neighbourPos = chessboard.getNeighbour(explorePos, moveOperation);
                if(neighbourPos == null)
                {
                    continue;
                }
                ChessboardStatus neighbourStatus = chessboard.getPosStatus(neighbourPos);
                
                if(neighbourStatus == ChessboardStatus.GOAL)
                {
                    explorePos = neighbourPos;
                    explorePos.from = prevPos;

                    // goal is finded!
                    ChessboardPosition tmpPos;
                    for(tmpPos = explorePos; tmpPos != null ;tmpPos = tmpPos.from)
                    {
                        int[] coords = tmpPos.getCoords();
                        dllp.addFirst(coords[0], coords[1]);
                    }
                    return dllp;
                }
                if(neighbourStatus == ChessboardStatus.OPEN)
                {
                    ChessboardPosition tmpPos = neighbourPos;
                    tmpPos.from = prevPos;
                    posToExplore.enqueue(tmpPos);
                    chessboard.setPosStatus(tmpPos, ChessboardStatus.VISITED);
                }
            }
        }
        while( true );
        return null;
        
    }

}
